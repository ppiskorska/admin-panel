<?php
require 'db_connect.php';
$error = $message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin) {
        $token = bin2hex(random_bytes(16));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

        $update = $pdo->prepare("UPDATE admins SET reset_token = ?, reset_expires = ? WHERE email = ?");
        $update->execute([$token, $expires, $email]);

        $resetLink = "http://yourdomain.com/password_reset.php?token=$token";
        $message = "Password reset link: <a href='$resetLink'>$resetLink</a>";
    } else {
        $error = "Email not found.";
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Password Reset Request</title></head>
<body>
<h2>Request Password Reset</h2>
<form method="post" action="">
    <label>Email:</label><br>
    <input type="email" name="email" required><br><br>
    <button type="submit">Send Reset Link</button>
</form>
<?php
if ($error) echo "<p style='color:red;'>$error</p>";
if ($message) echo "<p style='color:green;'>$message</p>";
?>
</body>
</html>
