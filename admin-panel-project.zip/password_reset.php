<?php
require 'db_connect.php';
$error = $message = '';
$token = $_GET['token'] ?? '';

if (!$token) {
    die("Invalid token");
}

$stmt = $pdo->prepare("SELECT * FROM admins WHERE reset_token = ? AND reset_expires > NOW()");
$stmt->execute([$token]);
$admin = $stmt->fetch();

if (!$admin) {
    die("Token expired or invalid.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if ($newPassword !== $confirmPassword) {
        $error = "Passwords do not match.";
    } elseif (strlen($newPassword) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE admins SET password = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?");
        $update->execute([$hashed, $admin['id']]);
        $message = "Password successfully reset. You can <a href='admin_login.php'>login now</a>.";
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Reset Password</title></head>
<body>
<h2>Reset Password</h2>
<form method="post" action="">
    <label>New Password:</label><br>
    <input type="password" name="password" required><br><br>
    <label>Confirm Password:</label><br>
    <input type="password" name="confirm_password" required><br><br>
    <button type="submit">Reset Password</button>
</form>
<?php
if ($error) echo "<p style='color:red;'>$error</p>";
if ($message) echo "<p style='color:green;'>$message</p>";
?>
</body>
</html>
