# Admin Panel Project

Simple PHP + MySQL admin panel with:
- secure login (admin only)
- password reset
- role-based access

## Setup

1. Create your MySQL database
2. Import the `sql/create_admins_table.sql` script
3. Edit `db_connect.php` with your DB credentials
4. Upload to your PHP server
5. Access `admin_login.php`

## Notes

- For password reset, the link is displayed rather than emailed (demo only).
- Use PHP `password_hash` and `password_verify`.
